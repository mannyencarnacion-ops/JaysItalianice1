# Jay's Italian Ice — Shopify → Cloudflare cutover runbook

**Domain:** jaysitalianice1.com · **Old host:** Shopify (`c0t6st-pn.myshopify.com`) · **New host:** Cloudflare Pages
**Prepared:** 2026-07-19 (ShopMora)

---

## Why this one is low-risk
DNS captured live before any change (2026-07-19):

| Record | Current value | Action |
|---|---|---|
| Nameservers | GoDaddy — `ns19.domaincontrol.com`, `ns20.domaincontrol.com` | Move to Cloudflare |
| A `@` | `23.227.38.65` (Shopify) | Replaced by Pages |
| CNAME `www` | `shops.myshopify.com` | Replaced by Pages |
| **MX** | **none** | **No domain email — zero mail risk** |
| TXT `@` | `google-site-verification=HZCKN3X1-j2g6_od5QK5ff3J4NiB7IgggAZYGFsG_sU` | **Carry over verbatim** |
| DNSSEC | off | Safe to move nameservers |

Jay's email is plain Gmail (`jaysitalianice1@gmail.com`), not on the domain — so unlike Neat Nest, there is no MX to protect. The only record that must survive is the Google Search Console verification TXT.

---

## Step 1 — Deploy the site on Cloudflare Pages (do this FIRST, before touching DNS)
1. Push this repo to GitHub: `github.com/mannyencarnacion-ops/jays-italian-ice` (branch `main`).
2. Cloudflare dashboard → **Workers & Pages** → **Create** → **Pages** → **Connect to Git** → pick the repo.
3. Build settings: **Framework preset = None**, **Build command = (blank)**, **Output directory = `/`** (root).
4. Deploy. Confirm the site works at `jays-italian-ice.pages.dev` — click through flavors, events carousel, van image, all the Instagram/call links.

## Step 2 — Add the domain to Cloudflare
1. Cloudflare → **Add a domain** → `jaysitalianice1.com` → **Free** plan.
2. Cloudflare scans and imports existing records. **Verify the Search Console TXT imported:**
   - `TXT` `@` `google-site-verification=HZCKN3X1-j2g6_od5QK5ff3J4NiB7IgggAZYGFsG_sU` — add it manually if missing.
3. Delete the old Shopify `A @ 23.227.38.65` and `CNAME www → shops.myshopify.com` (Step 4 replaces them). Leaving them is fine too — attaching the custom domain overrides them.

## Step 3 — Move nameservers at GoDaddy
1. GoDaddy → **My Products** → `jaysitalianice1.com` → **DNS** → **Nameservers** → **Change** → **I'll use my own nameservers**.
2. Enter the two Cloudflare nameservers shown on the Cloudflare overview screen (e.g. `xxx.ns.cloudflare.com`).
3. Save. Propagation is ~15 min to a few hours; Cloudflare emails you when the zone is **Active**.

## Step 4 — Attach the domain to the Pages project
1. Pages project → **Custom domains** → **Set up a custom domain** → add `jaysitalianice1.com`.
2. Add `www.jaysitalianice1.com` as well.
3. Cloudflare auto-creates the records (apex + www → `jays-italian-ice.pages.dev`) and issues SSL. **This is the moment the live site switches from Shopify to the new build.**

## Step 5 — Verify
- `https://jaysitalianice1.com` and `https://www.jaysitalianice1.com` both load the new site (hard refresh: Ctrl+Shift+R).
- SSL padlock is valid.
- Spot-check: hero mascot, flavor cards, events carousel arrows, van photo, "Message us on Instagram", `tel:` and `mailto:` links.
- Send a test email to `jaysitalianice1@gmail.com` from another account and confirm it arrives (should be unaffected — no MX changed, but confirm).

## Step 6 — SEO
- Google Search Console → property `jaysitalianice1.com` → **Sitemaps** → submit `https://jaysitalianice1.com/sitemap.xml`.
- Request indexing for `https://jaysitalianice1.com/`.
- The Search Console verification stays valid because the TXT was carried in Step 2.

## Step 7 — Retire Shopify (LAST, only after Steps 5–6 pass)
- Confirm the domain serves from Cloudflare for a full day and nothing is broken.
- In Shopify admin, remove `jaysitalianice1.com` from **Settings → Domains** (so Shopify stops claiming it).
- Downgrade / cancel the Shopify plan (`c0t6st-pn.myshopify.com`). Keep the store in pause-and-build or export first if you want the old theme archived — the theme export is already saved.

---

## Rollback
Until **Step 4**, the old Shopify site stays live — nothing is switched yet. If anything looks wrong:
- Don't attach the custom domain (or remove it from the Pages project), **or**
- In Cloudflare DNS re-add `A @ 23.227.38.65` (proxied off / DNS-only) and `CNAME www → shops.myshopify.com` to point back at Shopify.

The GoDaddy → Cloudflare nameserver move itself is safe to leave in place; DNS is just managed in Cloudflare now.

## After the move — where DNS lives
DNS is managed in **Cloudflare** from Step 3 onward. Editing records in GoDaddy no longer has any effect. Any future changes (email, subdomains) happen in Cloudflare.
